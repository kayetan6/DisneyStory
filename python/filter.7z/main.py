from Matcher import Matcher
import pandas as pd
import os

def join_text(row, is_movie=True, actor_movie_col="Name"):
    if is_movie:
        return "{year}:{award}".format(year = row["Year"], award = row["Award"])
    else:
        return "{year}:{award}:{movie}".format(year = row["Year"], award = row["Award"], movie = row[actor_movie_col])

awards = pd.read_csv("./data/academy-awards.csv")

is_win = awards["Winner"] == 1
awards = awards[is_win]

awards["Name_Cleaned"] = awards["Name"].apply(lambda row: row.lower().strip())
awards["Film_Cleaned"] = awards["Film"].astype(str).apply(lambda row: row.lower().strip())

dir_out = "./out"

# -------------------------------------------- Movies --------------------------------------------------------------
def compare_year(row):
    return abs(int(row["Year"]) - int(row["release_date"].split("/")[-1])) < 10

movies = pd.read_csv("./data/disney-movies.csv")

movies["Title_Cleaned"] = movies["movie_title"].apply(lambda row: row.lower().strip())

movies_merged_on_name_file = "movies_merged_on_name.csv"
movies_merged_on_film_file = "movies_merged_on_film.csv"

movies_merged_on_name_path = os.path.join(dir_out, movies_merged_on_name_file)
movies_merged_on_film_path = os.path.join(dir_out, movies_merged_on_film_file)

instance = Matcher(mainDf=awards, mainCol="Name_Cleaned", lookupDf=movies, lookupCol="Title_Cleaned")
movies_merged_on_name = instance.doWork(threshold=95, toDir=dir_out, fileOut=movies_merged_on_name_file)

instance = Matcher(mainDf=awards, mainCol="Film_Cleaned", lookupDf=movies, lookupCol="Title_Cleaned")
movies_merged_on_film = instance.doWork(threshold=95, toDir=dir_out, fileOut=movies_merged_on_film_file)

movies_merged = pd.concat([movies_merged_on_name, movies_merged_on_film])

is_within_ten_years = movies_merged.apply(compare_year, axis=1)
movies_merged = movies_merged[is_within_ten_years]

movies_merged["Award"] = movies_merged.apply(join_text, args=(True, None), axis=1)

movies_merged = movies_merged.groupby("Title_Cleaned")["Award"].apply(lambda x: ";".join(x.values)).reset_index()

result_movies = pd.merge(movies, movies_merged, how="left", on="Title_Cleaned").drop(["Title_Cleaned", "score"], axis=1)

result_movies.to_csv("./out/disney-movies-awards.csv", index=False)

# -------------------------------------------- Actors --------------------------------------------------------------
actors = pd.read_csv("./data/disney-voice-actors.csv", encoding="latin_1")

actors["Actor_Cleaned"] = actors["voice-actor"].apply(lambda row: row.lower().strip())

actors_merged_on_name_file = "actors_merged_on_name.csv"
actors_merged_on_film_file = "actors_merged_on_film.csv"

actors_merged_on_name_path = os.path.join(dir_out, actors_merged_on_name_file)
actors_merged_on_film_path = os.path.join(dir_out, actors_merged_on_film_file)

instance = Matcher(mainDf=awards, mainCol="Name_Cleaned", lookupDf=actors, lookupCol="Actor_Cleaned")
actors_merged_on_name = instance.doWork(threshold=95, toDir=dir_out, fileOut=actors_merged_on_name_file)
actors_merged_on_name["Award"] = actors_merged_on_name.apply(join_text, args=(False, "Film"), axis=1)

instance = Matcher(mainDf=awards, mainCol="Film_Cleaned", lookupDf=actors, lookupCol="Actor_Cleaned")
actors_merged_on_film = instance.doWork(threshold=95, toDir=dir_out, fileOut=actors_merged_on_film_file)
actors_merged_on_film["Award"] = actors_merged_on_film.apply(join_text, args=(False, "Name"), axis=1)

actors_merged = pd.concat([actors_merged_on_name, actors_merged_on_film])

actors_merged = actors_merged.groupby("Actor_Cleaned")["Award"].apply(lambda x: ";".join(x.values)).reset_index()

result_actors = pd.merge(actors, actors_merged, how="left", on="Actor_Cleaned").drop(["Actor_Cleaned", "score"], axis=1)

result_actors.to_csv("./out/disney-actors-awards.csv", index=False)
